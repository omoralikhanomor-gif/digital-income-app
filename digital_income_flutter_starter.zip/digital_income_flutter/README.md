# Digital Income — Flutter Android starter

A Bengali-first UI prototype for a multi-country buy/sell marketplace.

## Run
1. Install Flutter SDK and Android Studio.
2. From this folder run `flutter create .` to generate Android platform files.
3. Run `flutter pub get`.
4. Run `flutter run` on an Android device or emulator.

## Included prototype screens
- Marketplace home, search, category filters and sample listings
- Product detail and add-listing form
- Account, messages, orders and phone-login UI
- Language selector labels for Bengali, English and Arabic (localization is not yet implemented)
- Bonus estimator: per completed ৳500 transaction unit, buyer gets ৳10 and seller gets ৳10
- No advertising monetization in the product plan

## Important limitations
This is a front-end prototype, not a production marketplace. OTP, user accounts, image uploads, database, real chat, payment processing, order verification, refunds, fraud prevention, wallet ledger, bonus payouts, and admin dashboard require backend services and security testing. The bonus screen is a local calculator only; it does not issue or transfer money. Do not accept real payments or promise cash rewards until the reward budget, terms, legal requirements, and backend settlement are implemented.

## Bonus rule in this prototype
For each completed and verified order, count full ৳500 units: `floor(order_amount / 500)`. Buyer bonus = units × ৳10; seller bonus = units × ৳10; platform bonus liability = units × ৳20. This is calculated per order; partial amounts do not roll over between orders unless the business policy is deliberately changed.

## Added: order-by-order bonus ledger prototype
- Added a sample bonus ledger screen reachable from the bonus calculator.
- Each order is calculated independently using `floor(order_amount / 500) * 10` for each side.
- Remainders do not roll over between separate orders (e.g. ৳300 + ৳200 in two orders earns ৳0 on both).
- Ledger entries shown are illustrative sample data, not real users, orders, wallet balances, or payments.

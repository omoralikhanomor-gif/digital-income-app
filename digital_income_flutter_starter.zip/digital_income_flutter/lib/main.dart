import 'package:flutter/material.dart';

void main() => runApp(const DigitalIncomeApp());

const navy = Color(0xFF12324A);
const mint = Color(0xFF16A477);

class DigitalIncomeApp extends StatelessWidget {
  const DigitalIncomeApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Digital Income',
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: mint), scaffoldBackgroundColor: const Color(0xFFF6F8FA), appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF6F8FA), foregroundColor: navy)),
    home: const MarketplaceHome(),
  );
}

class Product {
  final String title, price, location, category, emoji;
  final bool used;
  const Product(this.title, this.price, this.location, this.category, this.emoji, {this.used = false});
}

const products = <Product>[
  Product('স্মার্টফোন 128GB', '৳ ১৮,৫০০', 'ঢাকা', 'ইলেকট্রনিক্স', '📱'),
  Product('সাইকেল — ভালো অবস্থা', '৳ ৪,২০০', 'চট্টগ্রাম', 'যানবাহন', '🚲', used: true),
  Product('হ্যান্ডমেড পাঞ্জাবি', '৳ ১,২৫০', 'বরিশাল', 'ফ্যাশন', '👕'),
  Product('বাসার ইলেকট্রিক কাজ', '৳ ৫০০ থেকে', 'খুলনা', 'সার্ভিস', '🧰'),
];

class MarketplaceHome extends StatefulWidget {
  const MarketplaceHome({super.key});
  @override State<MarketplaceHome> createState() => _MarketplaceHomeState();
}
class _MarketplaceHomeState extends State<MarketplaceHome> {
  int tab = 0;
  String category = 'সব';
  String query = '';
  final categories = const ['সব', 'ইলেকট্রনিক্স', 'ফ্যাশন', 'যানবাহন', 'সার্ভিস', 'বাসা-বাড়ি'];
  @override
  Widget build(BuildContext context) {
    final pages = [home(), const MessagesPage(), const OrdersPage(), const AccountPage()];
    return Scaffold(
      appBar: AppBar(titleSpacing: 18, title: Row(children: [Container(width: 36, height: 36, decoration: BoxDecoration(color: navy, borderRadius: BorderRadius.circular(11)), child: const Icon(Icons.shopping_bag_outlined, color: Colors.white)), const SizedBox(width: 9), const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Digital Income', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)), Text('BUY • SELL • EARN', style: TextStyle(fontSize: 9, letterSpacing: 1.2, color: mint, fontWeight: FontWeight.bold))])]), actions: [IconButton(onPressed: () => showLanguage(context), icon: const Icon(Icons.language)), IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none))]),
      body: pages[tab],
      floatingActionButton: FloatingActionButton.extended(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AddListingPage())), backgroundColor: mint, foregroundColor: Colors.white, icon: const Icon(Icons.add), label: const Text('বিক্রি করুন')),
      bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v), destinations: const [NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'হোম'), NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'মেসেজ'), NavigationDestination(icon: Icon(Icons.receipt_long_outlined), label: 'অর্ডার'), NavigationDestination(icon: Icon(Icons.person_outline), label: 'অ্যাকাউন্ট')]),
    );
  }
  Widget home() {
    final filtered = products.where((p) => (category == 'সব' || p.category == category) && (p.title.toLowerCase().contains(query.toLowerCase()) || p.location.contains(query))).toList();
    return ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 100), children: [
      Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(gradient: const LinearGradient(colors: [navy, Color(0xFF1B5964)]), borderRadius: BorderRadius.circular(20)), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('আপনার কেনাবেচা শুরু করুন', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)), SizedBox(height: 6), Text('কিনুন, বিক্রি করুন, আয় করুন — এক জায়গায়।', style: TextStyle(color: Colors.white70)), SizedBox(height: 14), Row(children: [Icon(Icons.verified_user_outlined, color: Color(0xFF8DE2C4), size: 17), SizedBox(width: 6), Text('সহজ • দ্রুত • নিরাপদ মার্কেটপ্লেস', style: TextStyle(color: Color(0xFFB9F0DC), fontSize: 12))])])),
      const SizedBox(height: 14), InkWell(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BonusCalculatorPage())), borderRadius: BorderRadius.circular(16), child: Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFFE3F7EF), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFB8E8D5))), child: const Row(children: [Icon(Icons.card_giftcard, color: mint, size: 30), SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('প্রতি ৳৫০০ কেনাবেচায় ৳১০ বোনাস', style: TextStyle(fontWeight: FontWeight.bold, color: navy)), Text('ক্রেতা ও বিক্রেতা দুজনের জন্য • শর্ত প্রযোজ্য', style: TextStyle(fontSize: 11, color: Colors.black54))])), Icon(Icons.chevron_right, color: navy)]))), const SizedBox(height: 16), TextField(onChanged: (v) => setState(() => query = v), decoration: InputDecoration(hintText: 'কী খুঁজছেন?', prefixIcon: const Icon(Icons.search), filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none))),
      const SizedBox(height: 18), const Text('ক্যাটাগরি', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: navy)), const SizedBox(height: 10), SizedBox(height: 42, child: ListView(scrollDirection: Axis.horizontal, children: categories.map((c) => Padding(padding: const EdgeInsets.only(right: 8), child: ChoiceChip(label: Text(c), selected: category == c, onSelected: (_) => setState(() => category = c), selectedColor: const Color(0xFFD9F4EA)))).toList())),
      const SizedBox(height: 16), Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('সাম্প্রতিক পণ্য ও সেবা', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: navy)), Text('${filtered.length}টি পাওয়া গেছে', style: const TextStyle(fontSize: 11, color: Colors.black54))]), const SizedBox(height: 10),
      GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: filtered.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 11, mainAxisSpacing: 11, childAspectRatio: .79), itemBuilder: (_, i) => ProductCard(product: filtered[i])),
      if (filtered.isEmpty) const Padding(padding: EdgeInsets.all(30), child: Center(child: Text('কোনো পণ্য পাওয়া যায়নি'))),
      const SizedBox(height: 18), const Text('নিরাপদ কেনাবেচার পরামর্শ', style: TextStyle(fontWeight: FontWeight.bold, color: navy)), const SizedBox(height: 6), const Text('পণ্য দেখে নিন, বিক্রেতার পরিচয় যাচাই করুন এবং অপরিচিত কাউকে অগ্রিম টাকা পাঠাবেন না।', style: TextStyle(color: Colors.black54, fontSize: 12)),
    ]);
  }
  void showLanguage(BuildContext context) { showModalBottomSheet(context: context, builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [const ListTile(title: Text('ভাষা নির্বাচন করুন', style: TextStyle(fontWeight: FontWeight.bold))), ListTile(title: const Text('বাংলা'), trailing: const Icon(Icons.check, color: mint), onTap: () => Navigator.pop(context)), ListTile(title: const Text('English'), onTap: () => Navigator.pop(context)), ListTile(title: const Text('العربية'), onTap: () => Navigator.pop(context))]))); }
}

class ProductCard extends StatelessWidget {
  final Product product; const ProductCard({super.key, required this.product});
  @override Widget build(BuildContext context) => InkWell(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProductDetails(product: product))), borderRadius: BorderRadius.circular(15), child: Container(decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(15), border: Border.all(color: const Color(0xFFE8EDF0))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: Container(width: double.infinity, decoration: BoxDecoration(color: const Color(0xFFEAF4F1), borderRadius: const BorderRadius.vertical(top: Radius.circular(15))), child: Center(child: Text(product.emoji, style: const TextStyle(fontSize: 54)))),), Padding(padding: const EdgeInsets.fromLTRB(10, 8, 10, 10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(product.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)), const SizedBox(height: 4), Text(product.price, style: const TextStyle(color: mint, fontWeight: FontWeight.w800, fontSize: 16)), const SizedBox(height: 4), Row(children: [const Icon(Icons.location_on_outlined, size: 13, color: Colors.black45), Text(product.location, style: const TextStyle(fontSize: 11, color: Colors.black54)), const Spacer(), if (product.used) const Text('পুরোনো', style: TextStyle(fontSize: 10, color: Colors.deepOrange))])]))])));
}

class ProductDetails extends StatelessWidget { final Product product; const ProductDetails({super.key, required this.product}); @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('পণ্যের বিবরণ')), body: ListView(padding: const EdgeInsets.all(18), children: [Container(height: 220, decoration: BoxDecoration(color: const Color(0xFFEAF4F1), borderRadius: BorderRadius.circular(18)), child: Center(child: Text(product.emoji, style: const TextStyle(fontSize: 90)))), const SizedBox(height: 18), Text(product.title, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold)), Text(product.price, style: const TextStyle(color: mint, fontWeight: FontWeight.bold, fontSize: 22)), ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.location_on_outlined), title: Text(product.location), subtitle: Text(product.category)), const Text('বিক্রেতার বিবরণ ও পণ্যের বিস্তারিত এখানে দেখানো হবে।', style: TextStyle(color: Colors.black54)), const SizedBox(height: 20), FilledButton.icon(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('চ্যাট সুবিধা ব্যাকএন্ড যুক্ত হলে চালু হবে।'))), icon: const Icon(Icons.chat), label: const Text('বিক্রেতার সঙ্গে যোগাযোগ'))])); }

class AddListingPage extends StatefulWidget { const AddListingPage({super.key}); @override State<AddListingPage> createState() => _AddListingPageState(); }
class _AddListingPageState extends State<AddListingPage> { final title = TextEditingController(), price = TextEditingController(), description = TextEditingController(), location = TextEditingController(); String category = 'ইলেকট্রনিক্স'; @override void dispose(){title.dispose();price.dispose();description.dispose();location.dispose();super.dispose();} @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('নতুন বিজ্ঞাপন দিন')), body: ListView(padding: const EdgeInsets.all(18), children: [Container(height: 125, decoration: BoxDecoration(color: const Color(0xFFEAF4F1), borderRadius: BorderRadius.circular(15)), child: const Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.add_a_photo_outlined, size: 32, color: mint), SizedBox(height: 6), Text('পণ্যের ছবি যোগ করুন') ])), const SizedBox(height: 16), field('পণ্যের / সেবার নাম', title), field('দাম (৳)', price, type: TextInputType.number), DropdownButtonFormField<String>(value: category, decoration: const InputDecoration(labelText: 'ক্যাটাগরি', border: OutlineInputBorder()), items: ['ইলেকট্রনিক্স','ফ্যাশন','যানবাহন','সার্ভিস','বাসা-বাড়ি'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(), onChanged:(v)=>setState(()=>category=v!)), const SizedBox(height: 12), field('অবস্থান / জেলা', location), field('বিস্তারিত বিবরণ', description, lines: 4), const SizedBox(height: 18), FilledButton(onPressed: () { if(title.text.trim().isEmpty || price.text.trim().isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('নাম ও দাম লিখুন')));return;} ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ডেমো: বিজ্ঞাপন ফর্ম প্রস্তুত। প্রকাশের জন্য সার্ভার সংযোগ প্রয়োজন।'))); }, child: const Text('বিজ্ঞাপন জমা দিন'))])); } Widget field(String label, TextEditingController c, {TextInputType? type, int lines=1}) => Padding(padding: const EdgeInsets.only(bottom: 12), child: TextField(controller:c, keyboardType:type, maxLines:lines, decoration: InputDecoration(labelText:label, border: const OutlineInputBorder()))); }

class MessagesPage extends StatelessWidget { const MessagesPage({super.key}); @override Widget build(BuildContext context) => const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.chat_bubble_outline, size: 48, color: mint), SizedBox(height: 10), Text('আপনার মেসেজ এখানে দেখা যাবে'), Text('চ্যাট চালু করতে সার্ভার সংযোগ প্রয়োজন', style: TextStyle(color: Colors.black54, fontSize: 12))])); }
class OrdersPage extends StatelessWidget { const OrdersPage({super.key}); @override Widget build(BuildContext context) => const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.receipt_long_outlined, size: 48, color: mint), SizedBox(height: 10), Text('আপনার অর্ডার এখানে দেখা যাবে'), Text('অর্ডার ব্যবস্থাপনা পরবর্তী ধাপে যুক্ত হবে', style: TextStyle(color: Colors.black54, fontSize: 12))])); }
class AccountPage extends StatelessWidget { const AccountPage({super.key}); @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [const CircleAvatar(radius: 38, backgroundColor: Color(0xFFD9F4EA), child: Icon(Icons.person, size: 42, color: navy)), const SizedBox(height: 12), const Center(child: Text('স্বাগতম!', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))), const Center(child: Text('মোবাইল নম্বর দিয়ে লগইন করুন', style: TextStyle(color: Colors.black54))), const SizedBox(height: 20), FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginPage())), icon: const Icon(Icons.phone_android), label: const Text('লগইন / অ্যাকাউন্ট খুলুন')), const SizedBox(height: 12), Card(child: Column(children: [const ListTile(leading: Icon(Icons.storefront_outlined), title: Text('আমার বিজ্ঞাপন')), const Divider(height: 1), ListTile(leading: const Icon(Icons.card_giftcard, color: mint), title: const Text('বোনাস ও ওয়ালেট'), subtitle: const Text('প্রতি ৳৫০০-তে ক্রেতা ৳১০ + বিক্রেতা ৳১০'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BonusCalculatorPage()))), const Divider(height: 1), const ListTile(leading: Icon(Icons.settings_outlined), title: Text('সেটিংস'))]))]); }
class LoginPage extends StatelessWidget { const LoginPage({super.key}); @override Widget build(BuildContext context) {final phone=TextEditingController(); return Scaffold(appBar:AppBar(title:const Text('মোবাইল দিয়ে লগইন')),body:Padding(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[const Text('আপনার মোবাইল নম্বর লিখুন',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),const SizedBox(height:12),TextField(controller:phone,keyboardType:TextInputType.phone,decoration:const InputDecoration(prefixText:'+880 ',hintText:'1XXXXXXXXX',border:OutlineInputBorder())),const SizedBox(height:14),FilledButton(onPressed:()=>ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('OTP পাঠাতে SMS gateway ও backend সংযোগ প্রয়োজন।'))),child:const Text('OTP পাঠান')),const SizedBox(height:8),const Text('এটি প্রাথমিক UI ডেমো। বাস্তব OTP যাচাই সার্ভার যুক্ত হলে কাজ করবে।',style:TextStyle(color:Colors.black54,fontSize:12))])));}}


// Demo-only bonus estimator. Production rewards must be issued from a trusted backend
// after payment/order completion and refund/fraud checks.
class BonusCalculatorPage extends StatefulWidget {
  const BonusCalculatorPage({super.key});
  @override State<BonusCalculatorPage> createState() => _BonusCalculatorPageState();
}
class _BonusCalculatorPageState extends State<BonusCalculatorPage> {
  final amount = TextEditingController(text: '500');
  bool completed = true;
  int get value => int.tryParse(amount.text.trim()) ?? 0;
  int get units => value < 0 ? 0 : value ~/ 500;
  int get eachBonus => units * 10;
  @override void dispose() { amount.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('বোনাস ও ওয়ালেট হিসাব')),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(gradient: const LinearGradient(colors: [navy, Color(0xFF1B5964)]), borderRadius: BorderRadius.circular(18)), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.card_giftcard, color: Color(0xFF8DE2C4), size: 32), SizedBox(height: 10), Text('BUY & SELL BONUS', style: TextStyle(color: Colors.white70, letterSpacing: 1.1)), SizedBox(height: 5), Text('প্রতি ৳৫০০-তে ৳১০', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 24)), Text('সম্পন্ন ও যাচাইকৃত অর্ডারের জন্য', style: TextStyle(color: Colors.white70, fontSize: 12))])),
      const SizedBox(height: 20), const Text('লেনদেনের পরিমাণ লিখুন', style: TextStyle(fontWeight: FontWeight.bold, color: navy)), const SizedBox(height: 8), TextField(controller: amount, keyboardType: TextInputType.number, onChanged: (_) => setState(() {}), decoration: const InputDecoration(prefixText: '৳ ', hintText: 'যেমন ১৫০০', border: OutlineInputBorder())),
      const SizedBox(height: 12), SwitchListTile(contentPadding: EdgeInsets.zero, value: completed, onChanged: (v) => setState(() => completed = v), title: const Text('অর্ডার সম্পন্ন ও যাচাইকৃত'), subtitle: const Text('অসম্পন্ন/বাতিল অর্ডারে বোনাস গণনা হবে না')),
      const SizedBox(height: 12), Row(children: [Expanded(child: _bonusTile('ক্রেতার বোনাস', completed ? eachBonus : 0, Icons.shopping_bag_outlined)), const SizedBox(width: 10), Expanded(child: _bonusTile('বিক্রেতার বোনাস', completed ? eachBonus : 0, Icons.storefront_outlined))]),
      const SizedBox(height: 12),
      Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: const Color(0xFFE3F7EF), borderRadius: BorderRadius.circular(14)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('প্ল্যাটফর্মের মোট বোনাস দায়', style: TextStyle(color: navy, fontWeight: FontWeight.bold)), const SizedBox(height: 5), Text('৳${completed ? eachBonus * 2 : 0}', style: const TextStyle(fontSize: 26, color: mint, fontWeight: FontWeight.w800)), Text('$unitsটি পূর্ণ ৳৫০০ ইউনিট × ৳২০ (দুই পক্ষ মিলিয়ে)', style: const TextStyle(fontSize: 11, color: Colors.black54))])),
      const SizedBox(height: 14), Text('হিসাব: ৳৫০০-এর পূর্ণ গুণিতক × ৳১০। উদাহরণ: ৳১,২৫০ লেনদেনে ২টি ইউনিট, তাই ক্রেতা ৳২০ এবং বিক্রেতা ৳২০ পাবেন। অবশিষ্ট ৳২৫০ পরের লেনদেনের সঙ্গে যোগ হবে না—এটি অর্ডারভিত্তিক হিসাব।', style: const TextStyle(fontSize: 12, color: Colors.black54)),
      const SizedBox(height: 12),
      OutlinedButton.icon(
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BonusLedgerPage())),
        icon: const Icon(Icons.receipt_long_outlined),
        label: const Text('অর্ডারভিত্তিক বোনাসের হিসাব দেখুন'),
      ),
      const SizedBox(height: 12), const Text('নোট: এটি এখন UI-তে হিসাব দেখানোর ডেমো। বাস্তবে বোনাস জমা দিতে সার্ভার-ভিত্তিক অর্ডার যাচাই, পেমেন্ট নিশ্চিতকরণ, রিফান্ড ও প্রতারণা-নিয়ন্ত্রণ লাগবে।', style: TextStyle(fontSize: 12, color: Colors.deepOrange)),
    ]),
  );
  Widget _bonusTile(String label, int amount, IconData icon) => Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFE8EDF0))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: mint), const SizedBox(height: 8), Text(label, style: const TextStyle(fontSize: 12, color: Colors.black54)), Text('৳$amount', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: mint))]));
}


// Demonstration ledger: each order is calculated independently; remainders never roll over.
class BonusLedgerPage extends StatelessWidget {
  const BonusLedgerPage({super.key});

  static const entries = <_BonusEntry>[
    _BonusEntry('DI-1001', '৳৫০০', 10, 'Approved', 'সম্পন্ন'),
    _BonusEntry('DI-1002', '৳৭৫০', 10, 'Pending', 'যাচাই চলছে'),
    _BonusEntry('DI-1003', '৳১,০০০', 20, 'Paid', 'বোনাস দেওয়া হয়েছে'),
    _BonusEntry('DI-1004', '৳৪৯৯', 0, '—', 'বোনাসের সীমা পূরণ হয়নি'),
    _BonusEntry('DI-1005', '৳৩০০', 0, '—', 'বোনাসের সীমা পূরণ হয়নি'),
    _BonusEntry('DI-1006', '৳২০০', 0, '—', 'আলাদা অর্ডার; আগেরটির সঙ্গে যোগ হবে না'),
  ];

  @override
  Widget build(BuildContext context) {
    const totalBuyer = 40;
    const totalSeller = 40;
    return Scaffold(
      appBar: AppBar(title: const Text('অর্ডারভিত্তিক বোনাসের হিসাব')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(children: [
            Expanded(child: _summary('ক্রেতার বোনাস', totalBuyer, Icons.shopping_bag_outlined)),
            const SizedBox(width: 10),
            Expanded(child: _summary('বিক্রেতার বোনাস', totalSeller, Icons.storefront_outlined)),
          ]),
          const SizedBox(height: 16),
          const Text('সাম্প্রতিক অর্ডার', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: navy)),
          const SizedBox(height: 8),
          ...entries.map((e) => Card(
            margin: const EdgeInsets.only(bottom: 9),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Expanded(child: Text(e.id, style: const TextStyle(fontWeight: FontWeight.bold, color: navy))),
                  Text(e.status, style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: e.status == 'Paid' ? mint : (e.status == 'Pending' ? Colors.deepOrange : Colors.black54))),
                ]),
                const SizedBox(height: 6),
                Row(children: [Text('অর্ডার মূল্য: ${e.amount}'), const Spacer(), Text('প্রত্যেকের বোনাস: ৳${e.bonus}', style: const TextStyle(fontWeight: FontWeight.bold, color: mint))]),
                const SizedBox(height: 3),
                Text(e.note, style: const TextStyle(fontSize: 11, color: Colors.black54)),
              ]),
            ),
          )),
          const SizedBox(height: 8),
          const Text('এগুলো নমুনা ডেটা। বাস্তব অর্ডার ও বোনাসের তথ্য সার্ভার থেকে আসবে। বোনাস কেবল পেমেন্ট নিশ্চিত, অর্ডার সম্পন্ন এবং ফেরত/প্রতারণা যাচাইয়ের পর অনুমোদিত হবে।', style: TextStyle(fontSize: 12, color: Colors.deepOrange)),
        ],
      ),
    );
  }

  Widget _summary(String label, int amount, IconData icon) => Container(
    padding: const EdgeInsets.all(13),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFE8EDF0))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: mint), const SizedBox(height: 8), Text(label, style: const TextStyle(fontSize: 11, color: Colors.black54)),
      Text('৳$amount', style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800, color: mint)),
    ]),
  );
}

class _BonusEntry {
  final String id, amount, status, note;
  final int bonus;
  const _BonusEntry(this.id, this.amount, this.bonus, this.status, this.note);
}
